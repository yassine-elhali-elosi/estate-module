{
    'name': 'Estate Data Module',
    'depends': ['base', 'base_import_module'],
    'application': True
}